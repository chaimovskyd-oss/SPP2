import { useMemo, useState, type ReactElement } from "react";
import { PAGE_PRESETS, pageSetupFromPreset } from "@/core/pageSetup/presets";
import { unitToPx } from "@/core/units/conversion";
import type { GridCreateOptions } from "@/types/grid";
import type { MaskCreateOptions, MaskShape } from "@/types/mask";
import type { PageSetup, Unit } from "@/types/primitives";
import type { ProjectCustomerInfo } from "@/types/project";

interface DocumentSetupScreenProps {
  modeName: string;
  onBack: () => void;
  onCreate: (setup: PageSetup, options?: { grid?: Partial<GridCreateOptions>; mask?: Partial<MaskCreateOptions> }, customerInfo?: ProjectCustomerInfo) => void;
}

export function DocumentSetupScreen({ modeName, onBack, onCreate }: DocumentSetupScreenProps): ReactElement {
  const isGridMode = modeName === "grid";
  const isMaskMode = modeName === "mask";
  const [setupStep, setSetupStep] = useState<1 | 2>(1);
  const [presetId, setPresetId] = useState("a4");
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const basePreset = PAGE_PRESETS.find((preset) => preset.id === presetId) ?? PAGE_PRESETS[1];
  const [units, setUnits] = useState<Unit>(basePreset.units);
  const [dpi, setDpi] = useState(basePreset.dpi);
  const [bleed, setBleed] = useState(basePreset.bleed ?? 0);
  const [margins, setMargins] = useState(basePreset.margins ?? 0);
  const [safeArea, setSafeArea] = useState(basePreset.margins ?? 0);
  const [customSize, setCustomSize] = useState(false);
  const [customWidth, setCustomWidth] = useState(basePreset.width);
  const [customHeight, setCustomHeight] = useState(basePreset.height);
  const [gridRows, setGridRows] = useState(2);
  const [gridColumns, setGridColumns] = useState(3);
  const [gridSpacing, setGridSpacing] = useState(8);
  const [gridFillDirection, setGridFillDirection] = useState<"rtl" | "ltr">("rtl");
  const [maskShape, setMaskShape] = useState<MaskShape>("circle");
  const [maskWidth, setMaskWidth] = useState(40);
  const [maskHeight, setMaskHeight] = useState(40);
  const [maskKeepProportions, setMaskKeepProportions] = useState(true);
  const [maskSpacing, setMaskSpacing] = useState(5);
  const [maskSmartCrop, setMaskSmartCrop] = useState(true);
  const [customerName, setCustomerName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");

  const setup = useMemo(() => {
    const preset = PAGE_PRESETS.find((item) => item.id === presetId) ?? PAGE_PRESETS[1];
    const sourcePreset = customSize
      ? { ...preset, width: customWidth, height: customHeight, units, dpi }
      : { ...preset, dpi };
    const nextSetup = pageSetupFromPreset(sourcePreset, orientation);
    const bleedPx = unitToPx(bleed, units, dpi);
    const marginsPx = unitToPx(margins, units, dpi);
    const safeAreaPx = unitToPx(safeArea, units, dpi);
    return {
      ...nextSetup,
      units,
      dpi,
      bleed: marginsFromValue(bleedPx),
      margins: marginsFromValue(marginsPx),
      safeArea: marginsFromValue(safeAreaPx)
    };
  }, [bleed, customHeight, customSize, customWidth, dpi, margins, orientation, presetId, safeArea, units]);

  function handlePresetChange(nextPresetId: string): void {
    const preset = PAGE_PRESETS.find((item) => item.id === nextPresetId) ?? PAGE_PRESETS[1];
    setPresetId(nextPresetId);
    setUnits(preset.units);
    setDpi(preset.dpi);
    setBleed(preset.bleed ?? 0);
    setMargins(preset.margins ?? 0);
    setSafeArea(preset.margins ?? 0);
    setCustomSize(preset.id === "custom");
    setCustomWidth(preset.width);
    setCustomHeight(preset.height);
  }

  function createDocument(): void {
    onCreate(
      setup,
      {
        grid: isGridMode
          ? {
            rows: gridRows,
            columns: gridColumns,
            spacingX: unitToPx(gridSpacing, units, dpi),
            spacingY: unitToPx(gridSpacing, units, dpi),
            margins: setup.margins,
            fillDirection: gridFillDirection
          }
          : undefined,
        mask: isMaskMode
          ? {
              maskShape,
              maskWidth: unitToPx(maskWidth, units, dpi),
              maskHeight: unitToPx(maskHeight, units, dpi),
              keepProportions: maskKeepProportions,
              spacingX: unitToPx(maskSpacing, units, dpi),
              spacingY: unitToPx(maskSpacing, units, dpi),
              margins: setup.margins,
              smartCropEnabled: maskSmartCrop
            }
          : undefined
      },
      {
        customerName,
        phoneNumber,
        email
      }
    );
  }

  return (
    <main className="setup-shell" data-testid="document-setup-screen">
      <section className="setup-panel">
        <header className="setup-header">
          <div>
            <span>{isGridMode ? "מצב גריד" : isMaskMode ? "Mask Mode" : "עיצוב חופשי"}</span>
            <h1>{isGridMode && setupStep === 2 ? "הגדרת הגריד" : isMaskMode && setupStep === 2 ? "Mask setup" : "הגדרת דף"}</h1>
          </div>
          <button className="btn btn-ghost" onClick={onBack} type="button">
            חזרה
          </button>
        </header>

        {isGridMode || isMaskMode ? (
          <div className="setup-steps" aria-label="שלבי הגדרה">
            <span className={setupStep === 1 ? "active" : ""}>1. דף</span>
            <span className={setupStep === 2 ? "active" : ""}>{isMaskMode ? "2. Mask" : "2. גריד"}</span>
          </div>
        ) : null}

        {setupStep === 1 ? (
          <>
          <section className="setup-info-panel" aria-label="Customer / Project Info">
            <div className="panel-section-title">Customer / Project Info</div>
            <div className="setup-grid setup-info-grid">
              <label className="field">
                <span className="field-label">Customer Name</span>
                <input className="text-input" onChange={(event) => setCustomerName(event.target.value)} type="text" value={customerName} />
              </label>
              <label className="field">
                <span className="field-label">Phone Number</span>
                <input className="text-input" inputMode="tel" onChange={(event) => setPhoneNumber(event.target.value)} type="tel" value={phoneNumber} />
              </label>
              <label className="field">
                <span className="field-label">Email</span>
                <input className="text-input" inputMode="email" onChange={(event) => setEmail(event.target.value)} type="email" value={email} />
              </label>
            </div>
          </section>
          <div className="setup-grid">
            <label className="field">
              <span className="field-label">מידת דף</span>
              <select className="text-input" onChange={(event) => handlePresetChange(event.target.value)} value={presetId}>
                {PAGE_PRESETS.map((preset) => (
                  <option key={preset.id} value={preset.id}>{preset.name}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span className="field-label">יחידות</span>
              <select className="text-input" onChange={(event) => setUnits(event.target.value as Unit)} value={units}>
                <option value="mm">מ"מ</option>
                <option value="cm">ס"מ</option>
                <option value="inch">אינץ'</option>
                <option value="px">פיקסלים</option>
              </select>
            </label>
            <label className="field">
              <span className="field-label">DPI</span>
              <input className="text-input" min={72} max={1200} onChange={(event) => setDpi(Number(event.target.value) || 300)} type="number" value={dpi} />
            </label>
            <div className="field">
              <span className="field-label">כיוון</span>
              <div className="seg">
                <button className={orientation === "portrait" ? "on" : ""} onClick={() => setOrientation("portrait")} type="button">לאורך</button>
                <button className={orientation === "landscape" ? "on" : ""} onClick={() => setOrientation("landscape")} type="button">לרוחב</button>
                <button disabled type="button">כפולה</button>
              </div>
            </div>
            <label className="check-line">
              <input checked={customSize} onChange={(event) => setCustomSize(event.target.checked)} type="checkbox" />
              מידה מותאמת אישית
            </label>
            <SetupNumber disabled={!customSize} label={`רוחב (${units})`} onChange={setCustomWidth} value={customWidth} />
            <SetupNumber disabled={!customSize} label={`גובה (${units})`} onChange={setCustomHeight} value={customHeight} />
            <SetupNumber label={`בליד (${units})`} onChange={setBleed} value={bleed} />
            <SetupNumber label={`שוליים (${units})`} onChange={setMargins} value={margins} />
            <SetupNumber label={`אזור בטוח (${units})`} onChange={setSafeArea} value={safeArea} />
          </div>
          </>
        ) : isGridMode ? (
          <section className="setup-subpanel">
            <div className="panel-section-title">הגדרת גריד</div>
            <div className="setup-grid">
              <SetupNumber label="שורות" min={1} onChange={setGridRows} step={1} value={gridRows} />
              <SetupNumber label="עמודות" min={1} onChange={setGridColumns} step={1} value={gridColumns} />
              <SetupNumber label={`ריווח (${units})`} onChange={setGridSpacing} value={gridSpacing} />
              <div className="field">
                <span className="field-label">כיוון מילוי</span>
                <div className="seg">
                  <button className={gridFillDirection === "rtl" ? "on" : ""} onClick={() => setGridFillDirection("rtl")} type="button">מימין לשמאל</button>
                  <button className={gridFillDirection === "ltr" ? "on" : ""} onClick={() => setGridFillDirection("ltr")} type="button">משמאל לימין</button>
                </div>
              </div>
            </div>
            <GridPreview columns={gridColumns} rows={gridRows} />
          </section>
        ) : (
          <section className="setup-subpanel">
            <div className="panel-section-title">Mask setup</div>
            <div className="setup-grid">
              <label className="field">
                <span className="field-label">Mask shape</span>
                <select className="text-input" onChange={(event) => setMaskShape(event.target.value as MaskShape)} value={maskShape}>
                  <option value="circle">Circle</option>
                  <option value="roundedRect">Rounded rectangle</option>
                  <option value="heart">Heart</option>
                  <option value="star">Star</option>
                </select>
              </label>
              <SetupNumber label={`Mask width (${units})`} min={1} onChange={(value) => {
                setMaskWidth(value);
                if (maskKeepProportions) setMaskHeight(value);
              }} value={maskWidth} />
              <SetupNumber label={`Mask height (${units})`} min={1} onChange={(value) => {
                setMaskHeight(value);
                if (maskKeepProportions) setMaskWidth(value);
              }} value={maskHeight} />
              <label className="check-line">
                <input checked={maskKeepProportions} onChange={(event) => setMaskKeepProportions(event.target.checked)} type="checkbox" />
                Keep proportions
              </label>
              <SetupNumber label={`Spacing (${units})`} onChange={setMaskSpacing} value={maskSpacing} />
              <label className="check-line">
                <input checked={maskSmartCrop} onChange={(event) => setMaskSmartCrop(event.target.checked)} type="checkbox" />
                Use Smart Crop / Face Detection
              </label>
            </div>
            <MaskPreview shape={maskShape} />
          </section>
        )}

        <div className="setup-summary">
          <span>{Math.round(setup.size.width)} x {Math.round(setup.size.height)} px</span>
          <span>{setup.dpi} DPI</span>
          <span>{setup.printIntent}</span>
        </div>

        <div className="setup-actions">
          {(isGridMode || isMaskMode) && setupStep === 2 ? (
            <button className="btn btn-ghost" onClick={() => setSetupStep(1)} type="button">חזרה להגדרת דף</button>
          ) : null}
          {(isGridMode || isMaskMode) && setupStep === 1 ? (
            <button className="btn btn-accent setup-create" onClick={() => setSetupStep(2)} type="button">{isMaskMode ? "Continue to Mask setup" : "המשך להגדרת גריד"}</button>
          ) : (
            <button className="btn btn-accent setup-create" data-testid="create-document" onClick={createDocument} type="button">צור מסמך</button>
          )}
        </div>
      </section>
    </main>
  );
}

function SetupNumber({ disabled = false, label, min = 0, onChange, step = 0.5, value }: { disabled?: boolean; label: string; min?: number; onChange: (value: number) => void; step?: number; value: number }): ReactElement {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      <input className="text-input" disabled={disabled} min={min} onChange={(event) => onChange(Math.max(min, Number(event.target.value) || min))} step={step} type="number" value={value} />
    </label>
  );
}

function GridPreview({ rows, columns }: { rows: number; columns: number }): ReactElement {
  return (
    <div className="grid-setup-preview" style={{ gridTemplateColumns: `repeat(${Math.max(1, columns)}, 1fr)` }}>
      {Array.from({ length: Math.max(1, rows * columns) }).map((_, index) => (
        <span key={index}>{index + 1}</span>
      ))}
    </div>
  );
}

function MaskPreview({ shape }: { shape: MaskShape }): ReactElement {
  return (
    <div className="mask-setup-preview" aria-hidden="true">
      {Array.from({ length: 12 }).map((_, index) => (
        <span className={`mask-preview-shape mask-preview-${shape}`} key={index}>{index + 1}</span>
      ))}
    </div>
  );
}

function marginsFromValue(value: number): PageSetup["margins"] {
  return {
    top: value,
    right: value,
    bottom: value,
    left: value
  };
}
